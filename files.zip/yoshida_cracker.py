#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════╗
║           YOSHIDA_CRACKER — by Yosh-Senpai               ║
║         Hash Cracker | Dictionary + Brute Force          ║
║   Supports: MD5, SHA1, SHA256, SHA512, bcrypt            ║
║                                                           ║
║  [!] For authorized penetration testing only.            ║
║      Unauthorized use is illegal. omnia vanitas.         ║
╚═══════════════════════════════════════════════════════════╝
"""

import hashlib
import itertools
import string
import sys
import time
import argparse
import os

try:
    import bcrypt
    BCRYPT_AVAILABLE = True
except ImportError:
    BCRYPT_AVAILABLE = False


# ─────────────────────────────────────────
#  COLORS
# ─────────────────────────────────────────
class C:
    CYAN    = '\033[96m'
    PINK    = '\033[95m'
    GREEN   = '\033[92m'
    RED     = '\033[91m'
    YELLOW  = '\033[93m'
    DIM     = '\033[2m'
    BOLD    = '\033[1m'
    RESET   = '\033[0m'

def banner():
    print(f"""
{C.CYAN}╔══════════════════════════════════════════════════════════╗
║  {C.PINK}██╗   ██╗ ██████╗ ███████╗██╗  ██╗██╗██████╗  █████╗  {C.CYAN}║
║  {C.PINK}╚██╗ ██╔╝██╔═══██╗██╔════╝██║  ██║██║██╔══██╗██╔══██╗ {C.CYAN}║
║  {C.PINK} ╚████╔╝ ██║   ██║███████╗███████║██║██║  ██║███████║ {C.CYAN}║
║  {C.PINK}  ╚██╔╝  ██║   ██║╚════██║██╔══██║██║██║  ██║██╔══██║ {C.CYAN}║
║  {C.PINK}   ██║   ╚██████╔╝███████║██║  ██║██║██████╔╝██║  ██║ {C.CYAN}║
║  {C.PINK}   ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝╚═════╝ ╚═╝  ╚═╝{C.CYAN}║
║           {C.YELLOW}C R A C K E R{C.CYAN}  //  by Yosh-Senpai              ║
║      {C.DIM}MD5 · SHA1 · SHA256 · SHA512 · bcrypt{C.CYAN}              ║
╚══════════════════════════════════════════════════════════╝{C.RESET}
{C.DIM}  [!] For authorized use only. memento mori.{C.RESET}
""")


# ─────────────────────────────────────────
#  HASH DETECTION
# ─────────────────────────────────────────
HASH_LENGTHS = {
    32:  'md5',
    40:  'sha1',
    64:  'sha256',
    128: 'sha512',
}

def detect_hash_type(h):
    h = h.strip()
    if h.startswith('$2b$') or h.startswith('$2a$'):
        return 'bcrypt'
    return HASH_LENGTHS.get(len(h), None)


# ─────────────────────────────────────────
#  HASHING
# ─────────────────────────────────────────
def hash_word(word, algo):
    word_bytes = word.encode('utf-8', errors='ignore')
    if algo == 'md5':
        return hashlib.md5(word_bytes).hexdigest()
    elif algo == 'sha1':
        return hashlib.sha1(word_bytes).hexdigest()
    elif algo == 'sha256':
        return hashlib.sha256(word_bytes).hexdigest()
    elif algo == 'sha512':
        return hashlib.sha512(word_bytes).hexdigest()
    return None

def check_bcrypt(word, target_hash):
    if not BCRYPT_AVAILABLE:
        print(f"{C.RED}[!] bcrypt not installed. Run: pip install bcrypt{C.RESET}")
        sys.exit(1)
    try:
        return bcrypt.checkpw(word.encode(), target_hash.encode())
    except Exception:
        return False


# ─────────────────────────────────────────
#  DICTIONARY ATTACK
# ─────────────────────────────────────────
def dictionary_attack(target_hash, algo, wordlist_path):
    print(f"\n{C.CYAN}[*] Mode      : {C.YELLOW}Dictionary Attack{C.RESET}")
    print(f"{C.CYAN}[*] Wordlist  : {C.YELLOW}{wordlist_path}{C.RESET}")
    print(f"{C.CYAN}[*] Hash type : {C.YELLOW}{algo.upper()}{C.RESET}")
    print(f"{C.CYAN}[*] Target    : {C.PINK}{target_hash}{C.RESET}\n")

    if not os.path.exists(wordlist_path):
        print(f"{C.RED}[!] Wordlist not found: {wordlist_path}{C.RESET}")
        sys.exit(1)

    start = time.time()
    count = 0

    try:
        with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                word = line.strip()
                if not word:
                    continue
                count += 1

                if count % 5000 == 0:
                    elapsed = time.time() - start
                    speed = int(count / elapsed) if elapsed > 0 else 0
                    print(f"\r{C.DIM}  [{count:,} tried | {speed:,}/s | {word[:30]:<30}]{C.RESET}", end='', flush=True)

                if algo == 'bcrypt':
                    match = check_bcrypt(word, target_hash)
                else:
                    match = hash_word(word, algo) == target_hash

                if match:
                    elapsed = time.time() - start
                    print(f"\r{' ' * 70}")
                    print(f"{C.GREEN}[+] CRACKED! ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{C.RESET}")
                    print(f"{C.GREEN}[+] Hash     : {target_hash}{C.RESET}")
                    print(f"{C.GREEN}[+] Password : {C.BOLD}{word}{C.RESET}")
                    print(f"{C.GREEN}[+] Tried    : {count:,} words in {elapsed:.2f}s{C.RESET}")
                    return word

    except KeyboardInterrupt:
        print(f"\n{C.YELLOW}[!] Interrupted by user.{C.RESET}")
        sys.exit(0)

    elapsed = time.time() - start
    print(f"\r{' ' * 70}")
    print(f"{C.RED}[-] Not found in wordlist. ({count:,} words in {elapsed:.2f}s){C.RESET}")
    return None


# ─────────────────────────────────────────
#  BRUTE FORCE ATTACK
# ─────────────────────────────────────────
CHARSETS = {
    'digits':     string.digits,
    'lower':      string.ascii_lowercase,
    'upper':      string.ascii_uppercase,
    'alpha':      string.ascii_letters,
    'alnum':      string.ascii_letters + string.digits,
    'printable':  string.ascii_letters + string.digits + string.punctuation,
}

def brute_force_attack(target_hash, algo, min_len, max_len, charset_name):
    charset = CHARSETS.get(charset_name, CHARSETS['alnum'])

    print(f"\n{C.CYAN}[*] Mode      : {C.YELLOW}Brute Force Attack{C.RESET}")
    print(f"{C.CYAN}[*] Hash type : {C.YELLOW}{algo.upper()}{C.RESET}")
    print(f"{C.CYAN}[*] Length    : {C.YELLOW}{min_len} - {max_len}{C.RESET}")
    print(f"{C.CYAN}[*] Charset   : {C.YELLOW}{charset_name} ({len(charset)} chars){C.RESET}")
    print(f"{C.CYAN}[*] Target    : {C.PINK}{target_hash}{C.RESET}\n")

    if algo == 'bcrypt':
        print(f"{C.RED}[!] Brute force on bcrypt is extremely slow. Use dictionary mode instead.{C.RESET}")

    start = time.time()
    count = 0

    try:
        for length in range(min_len, max_len + 1):
            print(f"{C.DIM}  [~] Trying length {length}...{C.RESET}")
            for combo in itertools.product(charset, repeat=length):
                word = ''.join(combo)
                count += 1

                if count % 50000 == 0:
                    elapsed = time.time() - start
                    speed = int(count / elapsed) if elapsed > 0 else 0
                    print(f"\r{C.DIM}  [{count:,} tried | {speed:,}/s | {word:<15}]{C.RESET}", end='', flush=True)

                if algo == 'bcrypt':
                    match = check_bcrypt(word, target_hash)
                else:
                    match = hash_word(word, algo) == target_hash

                if match:
                    elapsed = time.time() - start
                    print(f"\r{' ' * 70}")
                    print(f"{C.GREEN}[+] CRACKED! ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{C.RESET}")
                    print(f"{C.GREEN}[+] Hash     : {target_hash}{C.RESET}")
                    print(f"{C.GREEN}[+] Password : {C.BOLD}{word}{C.RESET}")
                    print(f"{C.GREEN}[+] Tried    : {count:,} combos in {elapsed:.2f}s{C.RESET}")
                    return word

    except KeyboardInterrupt:
        print(f"\n{C.YELLOW}[!] Interrupted by user.{C.RESET}")
        sys.exit(0)

    elapsed = time.time() - start
    print(f"\r{' ' * 70}")
    print(f"{C.RED}[-] Not cracked. ({count:,} combos in {elapsed:.2f}s){C.RESET}")
    return None


# ─────────────────────────────────────────
#  IDENTIFY HASH (standalone)
# ─────────────────────────────────────────
def identify_hash(h):
    h = h.strip()
    algo = detect_hash_type(h)
    if algo:
        print(f"{C.CYAN}[*] Hash      : {C.PINK}{h}{C.RESET}")
        print(f"{C.GREEN}[+] Detected  : {algo.upper()}{C.RESET}")
    else:
        print(f"{C.RED}[!] Unknown hash format (len={len(h)}){C.RESET}")


# ─────────────────────────────────────────
#  GENERATE HASH (utility)
# ─────────────────────────────────────────
def generate_hash(word, algo):
    if algo == 'bcrypt':
        if not BCRYPT_AVAILABLE:
            print(f"{C.RED}[!] bcrypt not installed.{C.RESET}")
            return
        hashed = bcrypt.hashpw(word.encode(), bcrypt.gensalt()).decode()
    else:
        hashed = hash_word(word, algo)
    print(f"{C.CYAN}[*] Word      : {word}{C.RESET}")
    print(f"{C.CYAN}[*] Algorithm : {algo.upper()}{C.RESET}")
    print(f"{C.GREEN}[+] Hash      : {hashed}{C.RESET}")


# ─────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────
def main():
    banner()

    parser = argparse.ArgumentParser(
        description='YOSHIDA_CRACKER — Password & Hash Cracking Tool',
        formatter_class=argparse.RawTextHelpFormatter
    )

    subparsers = parser.add_subparsers(dest='command', help='Command')

    # ── crack
    crack_p = subparsers.add_parser('crack', help='Crack a hash')
    crack_p.add_argument('hash', help='Target hash to crack')
    crack_p.add_argument('-t', '--type', help='Hash type (auto-detect if omitted)',
                         choices=['md5','sha1','sha256','sha512','bcrypt'])
    crack_p.add_argument('-m', '--mode', choices=['dict','brute'], default='dict',
                         help='Attack mode: dict or brute (default: dict)')
    crack_p.add_argument('-w', '--wordlist', default='wordlist.txt',
                         help='Path to wordlist (dict mode)')
    crack_p.add_argument('--min', type=int, default=1, help='Min length (brute mode)')
    crack_p.add_argument('--max', type=int, default=6, help='Max length (brute mode)')
    crack_p.add_argument('--charset', default='alnum',
                         choices=list(CHARSETS.keys()),
                         help='Charset for brute force (default: alnum)')

    # ── identify
    id_p = subparsers.add_parser('identify', help='Identify hash type')
    id_p.add_argument('hash', help='Hash to identify')

    # ── generate
    gen_p = subparsers.add_parser('generate', help='Generate a hash from plaintext')
    gen_p.add_argument('word', help='Plaintext to hash')
    gen_p.add_argument('-t', '--type', default='sha256',
                       choices=['md5','sha1','sha256','sha512','bcrypt'],
                       help='Hash algorithm (default: sha256)')

    args = parser.parse_args()

    if args.command == 'identify':
        identify_hash(args.hash)

    elif args.command == 'generate':
        generate_hash(args.word, args.type)

    elif args.command == 'crack':
        algo = args.type or detect_hash_type(args.hash.strip())
        if not algo:
            print(f"{C.RED}[!] Could not detect hash type. Specify with -t{C.RESET}")
            sys.exit(1)

        if args.mode == 'dict':
            dictionary_attack(args.hash.strip(), algo, args.wordlist)
        elif args.mode == 'brute':
            brute_force_attack(args.hash.strip(), algo, args.min, args.max, args.charset)

    else:
        parser.print_help()
        print(f"""
{C.CYAN}Examples:{C.RESET}
  {C.DIM}# Auto-detect hash type and crack with wordlist{C.RESET}
  python yoshida_cracker.py crack 5f4dcc3b5aa765d61d8327deb882cf99 -w rockyou.txt

  {C.DIM}# Crack SHA256 hash with brute force (up to 5 chars){C.RESET}
  python yoshida_cracker.py crack <hash> -t sha256 -m brute --max 5 --charset lower

  {C.DIM}# Identify a hash{C.RESET}
  python yoshida_cracker.py identify 5f4dcc3b5aa765d61d8327deb882cf99

  {C.DIM}# Generate a SHA512 hash{C.RESET}
  python yoshida_cracker.py generate "password123" -t sha512
""")

if __name__ == '__main__':
    main()
