# yoshida_cracker 🔓

> *"omnia vanitas — everything's crackable if you look long enough."*

A command-line password & hash cracking tool by **Yosh-Senpai**.  
Built for authorized penetration testing and CTF challenges.

---

## Features

- **Auto-detects** hash type from length/format
- **Dictionary attack** — blast through a wordlist fast
- **Brute force** — generate and test every combination
- **Hash generation** — create hashes for testing
- **Supported algorithms:** MD5, SHA1, SHA256, SHA512, bcrypt

---

## Install

```bash
git clone https://github.com/Yosh-Senpai/yoshida_cracker
cd yoshida_cracker
pip install bcrypt
```

---

## Usage

### Crack a hash (dictionary)
```bash
python yoshida_cracker.py crack <hash> -w rockyou.txt
```

### Crack a hash (brute force)
```bash
python yoshida_cracker.py crack <hash> -m brute --max 5 --charset lower
```

### Specify hash type manually
```bash
python yoshida_cracker.py crack <hash> -t sha256 -w wordlist.txt
```

### Identify a hash
```bash
python yoshida_cracker.py identify 5f4dcc3b5aa765d61d8327deb882cf99
```

### Generate a hash
```bash
python yoshida_cracker.py generate "password123" -t sha512
```

---

## Options

| Flag | Description | Default |
|------|-------------|---------|
| `-t` | Hash type (`md5`, `sha1`, `sha256`, `sha512`, `bcrypt`) | auto-detect |
| `-m` | Mode: `dict` or `brute` | `dict` |
| `-w` | Wordlist path | `wordlist.txt` |
| `--min` | Min length (brute) | `1` |
| `--max` | Max length (brute) | `6` |
| `--charset` | `digits`, `lower`, `upper`, `alpha`, `alnum`, `printable` | `alnum` |

---

## Wordlists

Recommended wordlists for dictionary mode:
- [rockyou.txt](https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt)
- [SecLists](https://github.com/danielmiessler/SecLists)

---

## Disclaimer

> This tool is for **authorized penetration testing and educational use only**.  
> Using this against systems without explicit permission is illegal.  
> The author takes no responsibility for misuse.

---

*memento mori.*
